# marioruiz97.github.io
#_Curriculum Vitae - Mario Andrés Ruiz._

Para ingresar a la página con mi curriculum vitae sigue el enlace. 
[_Curriculum vitae Mario Ruiz_][enlaceCV]


[enlaceCV]:http://marioruiz97.github.io
